package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.weather.Model.ForecastDayModel;
import com.example.weather.Model.ForecastModel;
import com.example.weather.Model.WeatherModel;
import com.example.weather.Retrofit.ApiClient;
import com.example.weather.adapter.ForecastAdapter;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements ForecastAdapter.OnForecastListener {
    private static final String TAG = "MyActivity";
    TextView tv_location, tv_wind, tv_pressure, tv_precip, tv_humidity, tv_cloud;
    ArrayList<ForecastDayModel> forecastday=new ArrayList<>();
    private RecyclerView recyclerView;
    private ForecastAdapter forecastAdapter;
    private RecyclerView.LayoutManager layoutManager;
    public static MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_location = findViewById(R.id.tv_location);
        tv_wind = findViewById(R.id.tv_wind);
        tv_pressure = findViewById(R.id.tv_pressure);
        tv_precip= findViewById(R.id.tv_precip);
        tv_humidity = findViewById(R.id.tv_humidity);
        tv_cloud = findViewById(R.id.tv_cloud);

        recyclerView = findViewById(R.id.forecast_list);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mainActivity = this;
        getDataFromApi();
        getForecastFromApi();

    }

    private void getDataFromApi(){
        ApiClient.endpoint().getData()
                .enqueue(new Callback<WeatherModel>() {
                    @Override
                    public void onResponse(Call<WeatherModel> call, Response<WeatherModel> response) {
                        tv_location.setText("Location: "+response.body().getLocation().getName());
                        tv_wind.setText("Wind: "+Double.toString(response.body().getCurrent().getWind_kph()));
                        tv_pressure.setText("Pressure: "+Double.toString(response.body().getCurrent().getPressure_mb()));
                        tv_precip.setText("Precipitation: "+Double.toString(response.body().getCurrent().getPrecip_mm()));
                        tv_humidity.setText("Humidity: "+Double.toString(response.body().getCurrent().getHumidity()));
                        tv_cloud.setText("Cloud: "+Double.toString(response.body().getCurrent().getCloud()));


                    }

                    @Override
                    public void onFailure(Call<WeatherModel> call, Throwable t) {

                    }
                });

    }
    private void getForecastFromApi(){
        ApiClient.endpoint().getForecast()
                .enqueue(new Callback<WeatherModel>() {
                    @Override
                    public void onResponse(Call<WeatherModel> call, Response<WeatherModel> response) {
                        forecastday=response.body().getForecast().getForecastday();
                        forecastAdapter = new ForecastAdapter(forecastday, mainActivity);
                        recyclerView.setAdapter(forecastAdapter);
                    }

                    @Override
                    public void onFailure(Call<WeatherModel> call, Throwable t) {

                    }
                });
    }

    @Override
    public void onForecastClick(int position) {
        Intent intent = new Intent(this,DetailForecast.class);
        intent.putExtra("ForecastDay", forecastday.get(position));
        startActivity(intent);
        Log.d(TAG, "onForecastClick: clicked");
    }
}